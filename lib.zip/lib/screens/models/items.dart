class Item {
  final String name;
  final String time;
  final int stock;
  final String description;

  Item(this.name, this.time, this.stock, this.description);
}